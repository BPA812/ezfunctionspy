from setuptools import find_packages, setup

setup(
    name='ezfunctionsforpy',
    packages=find_packages(include=['ezfunctions']),
    version='0.0.1',
    description='A Library Aimed At Making Programming Easier',
    author='EzFunctions',
)
